package com.justplayer.urllauncher;

import android.content.Context;

public final class StreamLinkReceiver implements AutoCloseable {
    private final NetworkReceiver network=new NetworkReceiver(); private final BluetoothReceiver bluetooth;
    public StreamLinkReceiver(Context c){bluetooth=new BluetoothReceiver(c);}
    public void start(final Listener l){network.start(l::onUrl); bluetooth.start(l::onUrl);}
    public void close(){network.close(); bluetooth.close();}
    public interface Listener{void onUrl(String url);}
}
