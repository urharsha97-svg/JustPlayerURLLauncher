# Stream Link — two-app edition

Two separate Android apps:

- **Stream Link Sender** — phone-first URL sender (`com.streamlink.sender`).
- **Stream Link** — Android TV receiver/Just Player launcher (`com.streamlink.tv`).

The TV package is intentionally unique so an APK signed by a different key cannot collide with the older `com.justplayer.urllauncher` installation. The TV display name remains **Stream Link**.

URL transfer uses UTF-8 payload bytes, a length field, SHA-256 integrity verification, and an ACK. Sender retries failed Bluetooth/LAN transfers up to three times.

## Install

Install `Stream-Link-Sender.apk` on the phone and `Stream-Link-TV.apk` on the Android TV. Do not install the TV APK on the phone.

For Bluetooth, pair the phone and TV first. For Wi-Fi, keep both devices on the same LAN; discovery uses UDP broadcast and manual TV IP is available as fallback.
