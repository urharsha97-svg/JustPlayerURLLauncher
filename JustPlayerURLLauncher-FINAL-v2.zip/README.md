# Stream Link — Phone Sender + Android TV Receiver

A single Android APK designed to run smoothly on **both Android phones and Android TV**.

## How it works

- **Phone:** Sender UI. Paste a video URL and send it to the TV over Bluetooth or local Wi‑Fi.
- **Android TV:** Receiver UI. Keep Stream Link open; it listens for Bluetooth and Wi‑Fi transfers and places the received URL into the TV player screen.
- The same application ID is used on both devices: `com.justplayer.urllauncher`.

## URL integrity

The transfer protocol sends the URL as its original UTF‑8 bytes and includes:

- protocol magic + version
- exact byte length
- SHA‑256 checksum
- receiver ACK/NACK
- up to 3 sender retries

A checksum mismatch is rejected instead of opening a potentially altered URL.

## Wi‑Fi

Phone and TV must be on the same local network. Use **FIND TV ON WI‑FI** for discovery, or enter the TV's local IP manually.

## Bluetooth

Pair the phone and TV in Android Bluetooth settings first. Then use **SEND BY BLUETOOTH** and select the paired TV.

## Just Player

Install Just Player on the TV/phone if you want Stream Link's direct Just Player action. The app also provides the normal Android player chooser fallback.

## GitHub Actions

The included workflow builds a debug APK with JDK 17 and Gradle 8.7 and publishes the APK as a workflow artifact.
