package com.justplayer.urllauncher;

public class NetworkDevice {
    public final String name;
    public final String host;

    public NetworkDevice(String name, String host) {
        this.name = name;
        this.host = host;
    }
}
