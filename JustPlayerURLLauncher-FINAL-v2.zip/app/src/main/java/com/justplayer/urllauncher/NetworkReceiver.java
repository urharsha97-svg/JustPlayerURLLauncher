package com.justplayer.urllauncher;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class NetworkReceiver {
    private volatile boolean running;
    private Thread tcpThread;
    private Thread udpThread;
    private ServerSocket serverSocket;
    private DatagramSocket udpSocket;
    private final Context context;
    private final StreamLinkReceiver.Listener listener;

    public NetworkReceiver(Context context, StreamLinkReceiver.Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public void start() {
        if (running) return;
        running = true;

        tcpThread = new Thread(() -> {
            try (ServerSocket server = new ServerSocket(NetworkTransfer.TCP_PORT)) {
                serverSocket = server;
                while (running) {
                    try {
                        Socket socket = server.accept();
                        new Thread(() -> handleClient(socket)).start();
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }, "StreamLink-TCP");
        tcpThread.start();

        udpThread = new Thread(() -> {
            try (DatagramSocket socket = new DatagramSocket(NetworkTransfer.UDP_PORT)) {
                udpSocket = socket;
                socket.setBroadcast(true);
                byte[] buf = new byte[256];
                while (running) {
                    DatagramPacket request = new DatagramPacket(buf, buf.length);
                    socket.receive(request);
                    String text = new String(request.getData(), request.getOffset(), request.getLength(), StandardCharsets.US_ASCII);
                    if ("SLINK_DISCOVER_1".equals(text)) {
                        String name = android.os.Build.MODEL == null ? "Stream Link TV" : android.os.Build.MODEL;
                        byte[] response = ("SLINK_TV_1|" + name).getBytes(StandardCharsets.UTF_8);
                        DatagramPacket reply = new DatagramPacket(response, response.length, request.getAddress(), request.getPort());
                        socket.send(reply);
                    }
                }
            } catch (Exception ignored) {}
        }, "StreamLink-UDP");
        udpThread.start();
    }

    private void handleClient(Socket socket) {
        try (Socket s = socket;
             DataInputStream in = new DataInputStream(s.getInputStream());
             DataOutputStream out = new DataOutputStream(s.getOutputStream())) {
            try {
                String url = UrlTransferProtocol.read(in);
                if (url.trim().isEmpty()) throw new Exception("Empty URL");
                UrlTransferProtocol.writeAck(out, true);
                listener.onUrl(url);
            } catch (Exception e) {
                try { UrlTransferProtocol.writeAck(out, false); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        try { if (udpSocket != null) udpSocket.close(); } catch (Exception ignored) {}
    }
}
