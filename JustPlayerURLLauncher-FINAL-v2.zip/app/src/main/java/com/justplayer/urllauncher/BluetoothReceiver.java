package com.justplayer.urllauncher;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class BluetoothReceiver {
    private final Context context;
    private final StreamLinkReceiver.Listener listener;
    private volatile boolean running;
    private BluetoothServerSocket serverSocket;
    private Thread thread;

    public BluetoothReceiver(Context context, StreamLinkReceiver.Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return;
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord("Stream Link", BluetoothSender.UUID_STREAM_LINK);
                while (running) {
                    try {
                        BluetoothSocket socket = serverSocket.accept();
                        new Thread(() -> handle(socket)).start();
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }, "StreamLink-Bluetooth");
        thread.start();
    }

    private void handle(BluetoothSocket socket) {
        try (BluetoothSocket s = socket;
             DataInputStream in = new DataInputStream(s.getInputStream());
             DataOutputStream out = new DataOutputStream(s.getOutputStream())) {
            try {
                String url = UrlTransferProtocol.read(in);
                if (url.trim().isEmpty()) throw new Exception("Empty URL");
                UrlTransferProtocol.writeAck(out, true);
                listener.onUrl(url);
            } catch (Exception e) {
                try { UrlTransferProtocol.writeAck(out, false); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
    }
}
