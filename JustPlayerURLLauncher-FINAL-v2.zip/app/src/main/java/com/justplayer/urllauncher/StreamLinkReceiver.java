package com.justplayer.urllauncher;

import android.content.Context;

public class StreamLinkReceiver {
    public interface Listener { void onUrl(String url); }

    private final BluetoothReceiver bluetooth;
    private final NetworkReceiver network;

    public StreamLinkReceiver(Context context, Listener listener) {
        bluetooth = new BluetoothReceiver(context, listener);
        network = new NetworkReceiver(context, listener);
    }

    public void start() {
        bluetooth.start();
        network.start();
    }

    public void stop() {
        bluetooth.stop();
        network.stop();
    }
}
