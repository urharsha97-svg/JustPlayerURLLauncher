package com.justplayer.urllauncher;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class BluetoothReceiver {
    private static final java.util.UUID UUID_STREAM_LINK =
            java.util.UUID.fromString("7b1e8f40-8c36-4b1b-a9d5-3f8f7b3d7b11");
    private final Context context;
    private final StreamLinkReceiver.Listener listener;
    private volatile boolean running;
    private BluetoothServerSocket serverSocket;
    private Thread thread;

    public BluetoothReceiver(Context context, StreamLinkReceiver.Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public void start() {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return;
            if (android.os.Build.VERSION.SDK_INT >= 31 &&
                    (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED ||
                     context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) != android.content.pm.PackageManager.PERMISSION_GRANTED)) return;
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord("Stream Link", UUID_STREAM_LINK);
                while (running) {
                    try {
                        BluetoothSocket socket = serverSocket.accept();
                        new Thread(() -> handle(socket)).start();
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }, "StreamLink-Bluetooth");
        thread.start();
    }

    private void handle(BluetoothSocket socket) {
        try (BluetoothSocket s = socket;
             DataInputStream in = new DataInputStream(s.getInputStream());
             DataOutputStream out = new DataOutputStream(s.getOutputStream())) {
            try {
                String url = UrlTransferProtocol.read(in);
                if (url.trim().isEmpty()) throw new Exception("Empty URL");
                UrlTransferProtocol.writeAck(out, true);
                listener.onUrl(url);
            } catch (Exception e) {
                try { UrlTransferProtocol.writeAck(out, false); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
    }
}
