package com.justplayer.urllauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.UiModeManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private EditText urlInput;
    private EditText historySearch;
    private EditText favouritesSearch;

    private LinearLayout historyLayout;
    private LinearLayout favouritesLayout;

    private SharedPreferences prefs;

    private static final String PREFS = "player_data_v6";
    private static final String HISTORY = "history";
    private static final String FAVOURITES = "favourites";

    private static final String JUST_PLAYER_PACKAGE =
            "com.brouken.player";

    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int CARD = Color.rgb(17, 17, 17);
    private static final int CARD_2 = Color.rgb(25, 25, 25);
    private static final int CARD_3 = Color.rgb(30, 30, 30);

    private static final int FOCUS = Color.rgb(35, 75, 125);
    private static final int FOCUS_BORDER = Color.rgb(80, 160, 255);

    private static final int WHITE = Color.rgb(245, 245, 245);
    private static final int GREY = Color.rgb(165, 165, 165);

    private static final int BLUE =
            Color.rgb(120, 210, 255);

    private static final int GOLD = Color.rgb(255, 193, 7);

    private static final int SORT_NEWEST = 0;
    private static final int SORT_OLDEST = 1;
    private static final int SORT_AZ = 2;
    private static final int SORT_ZA = 3;

    private int historySort = SORT_NEWEST;
    private int favouritesSort = SORT_NEWEST;

    private StreamLinkReceiver tvReceiver;
    private final List<NetworkDevice> discoveredTvs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        getWindow().setNavigationBarColor(BLACK);
        getWindow().setStatusBarColor(BLACK);

        prefs = getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
        );

        if (isTvDevice()) {

            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            createUI();
            refreshHistory();
            refreshFavourites();
            startTvReceiver();

        } else {

            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            createSenderUI();
            handleIncomingShare(getIntent());
        }
    }

    private boolean isTvDevice() {

        UiModeManager uiModeManager =
                (UiModeManager) getSystemService(UI_MODE_SERVICE);

        if (uiModeManager == null) return false;

        int mode = uiModeManager.getCurrentModeType();

        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION;
    }

    private void startTvReceiver() {

        if (Build.VERSION.SDK_INT >= 31 &&
                (checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                 checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED)) {

            requestPermissions(
                    new String[]{
                            android.Manifest.permission.BLUETOOTH_CONNECT,
                            android.Manifest.permission.BLUETOOTH_ADVERTISE
                    },
                    7001
            );

            return;
        }

        if (tvReceiver != null) return;

        tvReceiver = new StreamLinkReceiver(this, url -> runOnUiThread(() -> receiveUrl(url)));
        tvReceiver.start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 7001) {
            boolean ok = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) ok = false;
            }

            if (ok && isTvDevice()) startTvReceiver();
        }
    }

    private void receiveUrl(String url) {

        if (url == null || url.isEmpty()) return;

        urlInput.setText(url);
        urlInput.setSelection(urlInput.length());
        addHistory(url);
        showMessage("✓ URL received");
    }

    private void createSenderUI() {

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setBackgroundColor(BLACK);

        TextView title = sectionTitle("STREAM LINK");
        root.addView(title, fullParams());

        TextView sub = makeText("PHONE URL SENDER", 22);
        sub.setTextColor(BLUE);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = fullParams();
        subP.bottomMargin = dp(18);
        root.addView(sub, subP);

        urlInput = new EditText(this);
        urlInput.setHint("Paste video URL here");
        urlInput.setHintTextColor(Color.rgb(115,115,115));
        urlInput.setTextColor(WHITE);
        urlInput.setTextSize(19);
        urlInput.setSingleLine(true);
        urlInput.setPadding(dp(16), dp(10), dp(16), dp(10));
        urlInput.setBackground(createInputBackground());
        root.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(68)));

        Button discover = makeButton("⌁  FIND TV ON WI-FI");
        LinearLayout.LayoutParams discoverP = fullParams();
        discoverP.height = dp(58);
        discoverP.topMargin = dp(14);
        root.addView(discover, discoverP);
        discover.setOnClickListener(v -> discoverTvs());

        Button bluetooth = makeButton("♢  SEND BY BLUETOOTH");
        LinearLayout.LayoutParams btP = fullParams();
        btP.height = dp(58);
        btP.topMargin = dp(8);
        root.addView(bluetooth, btP);
        bluetooth.setOnClickListener(v -> sendBluetooth());

        Button wifi = makeButton("↔  SEND OVER WI-FI");
        LinearLayout.LayoutParams wifiP = fullParams();
        wifiP.height = dp(58);
        wifiP.topMargin = dp(8);
        root.addView(wifi, wifiP);
        wifi.setOnClickListener(v -> sendWiFiDialog());

        Button share = makeButton("↗  ANDROID SHARE");
        LinearLayout.LayoutParams shareP = fullParams();
        shareP.height = dp(58);
        shareP.topMargin = dp(8);
        root.addView(share, shareP);
        share.setOnClickListener(v -> shareCurrentUrl());

        TextView info = makeText("Wi-Fi: TV and phone must be on the same local network.\nBluetooth: pair the phone and TV first in Android Bluetooth settings.", 15);
        info.setTextColor(GREY);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoP = fullParams();
        infoP.topMargin = dp(18);
        root.addView(info, infoP);

        setContentView(root);
    }

    private void handleIncomingShare(Intent intent) {

        if (intent == null) return;

        if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.hasExtra(Intent.EXTRA_TEXT)) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) urlInput.setText(text.trim());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (!isTvDevice()) handleIncomingShare(intent);
        else if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.hasExtra(Intent.EXTRA_TEXT)) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) receiveUrl(text.trim());
        }
    }

    private void shareCurrentUrl() {

        String url = getCurrentUrl();
        if (url.isEmpty()) {
            showMessage("Enter a URL first");
            return;
        }

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Send URL to TV / App"));
    }

    private void sendBluetooth() {

        String url = getCurrentUrl();
        if (url.isEmpty()) {
            showMessage("Enter a URL first");
            return;
        }

        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.BLUETOOTH_CONNECT}, 7002);
            return;
        }

        BluetoothSender.chooseAndSend(this, url, message -> runOnUiThread(() -> showMessage(message)));
    }

    private void discoverTvs() {

        showMessage("Searching for Stream Link TVs...");

        new Thread(() -> {
            List<NetworkDevice> found = NetworkTransfer.discoverTvs();

            runOnUiThread(() -> {
                discoveredTvs.clear();
                discoveredTvs.addAll(found);

                if (found.isEmpty()) {
                    showMessage("No TV found on this Wi-Fi");
                    return;
                }

                showTvPicker();
            });
        }).start();
    }

    private void showTvPicker() {

        String[] names = new String[discoveredTvs.size()];
        for (int i = 0; i < discoveredTvs.size(); i++) {
            NetworkDevice d = discoveredTvs.get(i);
            names[i] = d.name + "  •  " + d.host;
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Stream Link TV")
                .setItems(names, (dialog, which) -> sendToTv(discoveredTvs.get(which)))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void sendWiFiDialog() {

        String url = getCurrentUrl();
        if (url.isEmpty()) {
            showMessage("Enter a URL first");
            return;
        }

        final EditText ip = new EditText(this);
        ip.setHint("TV IP address (example: 192.168.1.20)");
        ip.setSingleLine(true);
        ip.setTextColor(WHITE);
        ip.setHintTextColor(GREY);
        ip.setPadding(dp(16), dp(10), dp(16), dp(10));
        ip.setBackground(createInputBackground());

        new AlertDialog.Builder(this)
                .setTitle("Send over Wi-Fi")
                .setMessage("You can use a discovered TV or enter its local IP address.")
                .setView(ip)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND", (dialog, which) -> {
                    String host = ip.getText().toString().trim();
                    if (!host.isEmpty()) sendToTv(new NetworkDevice("Stream Link TV", host));
                })
                .show();
    }

    private void sendToTv(NetworkDevice device) {

        String url = getCurrentUrl();
        if (url.isEmpty()) {
            showMessage("Enter a URL first");
            return;
        }

        showMessage("Sending URL...");

        new Thread(() -> {
            boolean ok = NetworkTransfer.sendUrl(device.host, url);
            runOnUiThread(() -> showMessage(ok ? "✓ URL sent successfully" : "✕ Wi-Fi transfer failed"));
        }).start();
    }

    @Override
    protected void onDestroy() {

        if (tvReceiver != null) {
            tvReceiver.stop();
            tvReceiver = null;
        }

        super.onDestroy();
    }

    private int dp(int value) {

        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density
                        + 0.5f
        );
    }

    private LinearLayout.LayoutParams fullParams() {

        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private StateListDrawable createButtonBackground() {

        GradientDrawable normal =
                new GradientDrawable();

        normal.setColor(CARD_2);
        normal.setCornerRadius(dp(10));
        normal.setStroke(
                dp(1),
                Color.rgb(45, 45, 45)
        );

        GradientDrawable focused =
                new GradientDrawable();

        focused.setColor(FOCUS);
        focused.setCornerRadius(dp(10));
        focused.setStroke(
                dp(3),
                FOCUS_BORDER
        );

        GradientDrawable pressed =
                new GradientDrawable();

        pressed.setColor(
                Color.rgb(50, 100, 160)
        );

        pressed.setCornerRadius(dp(10));
        pressed.setStroke(dp(3), Color.WHITE);

        StateListDrawable states =
                new StateListDrawable();

        states.addState(
                new int[]{
                        android.R.attr.state_pressed
                },
                pressed
        );

        states.addState(
                new int[]{
                        android.R.attr.state_focused
                },
                focused
        );

        states.addState(
                new int[]{},
                normal
        );

        return states;
    }

    private StateListDrawable createInputBackground() {

        GradientDrawable normal =
                new GradientDrawable();

        normal.setColor(CARD);
        normal.setCornerRadius(dp(10));
        normal.setStroke(
                dp(1),
                Color.rgb(50, 50, 50)
        );

        GradientDrawable focused =
                new GradientDrawable();

        focused.setColor(
                Color.rgb(20, 25, 32)
        );

        focused.setCornerRadius(dp(10));
        focused.setStroke(
                dp(3),
                FOCUS_BORDER
        );

        StateListDrawable states =
                new StateListDrawable();

        states.addState(
                new int[]{
                        android.R.attr.state_focused
                },
                focused
        );

        states.addState(
                new int[]{},
                normal
        );

        return states;
    }

    private Button makeButton(String text) {

        Button button =
                new Button(this);

        button.setId(
                View.generateViewId()
        );

        button.setText(text);
        button.setTextSize(17);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(WHITE);

        button.setFocusable(true);
        button.setFocusableInTouchMode(true);

        button.setPadding(
                dp(8),
                dp(4),
                dp(8),
                dp(4)
        );

        button.setBackground(
                createButtonBackground()
        );

        return button;
    }

    private LinearLayout.LayoutParams buttonWeightParams() {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        0,
                        dp(60),
                        1f
                );

        params.setMargins(
                dp(4),
                dp(4),
                dp(4),
                dp(4)
        );

        return params;
    }

    private TextView makeText(
            String text,
            float size
    ) {

        TextView view =
                new TextView(this);

        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(WHITE);

        return view;
    }

    private TextView sectionTitle(String text) {

        TextView title =
                new TextView(this);

        title.setText(text);
        title.setTextSize(25);
        title.setTextColor(WHITE);

        title.setGravity(Gravity.CENTER);

        title.setTypeface(
                null,
                Typeface.BOLD
        );

        return title;
    }

    private View createPremiumDivider() {

        View divider =
                new View(this);

        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                Color.rgb(55, 100, 155)
        );

        background.setCornerRadius(dp(4));

        divider.setBackground(background);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        dp(90),
                        dp(3)
                );

        params.gravity =
                Gravity.CENTER_HORIZONTAL;

        params.topMargin = dp(10);
        params.bottomMargin = dp(18);

        divider.setLayoutParams(params);

        return divider;
    }

    // =====================================================
    // MAIN UI
    // =====================================================

    private void createUI() {

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL
        );

        root.setGravity(
                Gravity.CENTER_HORIZONTAL
        );

        // TOP SPACE REDUCED
        root.setPadding(
                dp(55),
                dp(8),
                dp(55),
                dp(50)
        );

        root.setBackgroundColor(BLACK);

        scrollView.addView(root);

        // =================================================
        // STREAM LINK HEADER
        // =================================================

        TextView brand =
                new TextView(this);

        brand.setText(
                "STREAM LINK"
        );

        brand.setTextSize(16);

        brand.setTextColor(
                BLUE
        );

        brand.setGravity(
                Gravity.CENTER
        );

        brand.setTypeface(
                null,
                Typeface.BOLD
        );

        root.addView(
                brand,
                fullParams()
        );

        TextView title =
                new TextView(this);

        title.setText(
                "VIDEO URL LAUNCHER"
        );

        title.setTextSize(36);
        title.setTextColor(WHITE);

        title.setGravity(Gravity.CENTER);

        title.setTypeface(
                null,
                Typeface.BOLD
        );

        LinearLayout.LayoutParams titleParams =
                fullParams();

        titleParams.topMargin =
                dp(3);

        root.addView(
                title,
                titleParams
        );

        root.addView(
                createPremiumDivider()
        );

        TextView subtitle =
                makeText(
                        "Paste a video URL • Play instantly on your TV",
                        18
                );

        subtitle.setTextColor(GREY);
        subtitle.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams subtitleParams =
                fullParams();

        subtitleParams.bottomMargin =
                dp(25);

        root.addView(
                subtitle,
                subtitleParams
        );

        // =================================================
        // URL INPUT
        // =================================================

        urlInput =
                new EditText(this);

        urlInput.setHint(
                "Paste video URL here"
        );

        urlInput.setHintTextColor(
                Color.rgb(115, 115, 115)
        );

        urlInput.setTextColor(WHITE);
        urlInput.setSingleLine(true);
        urlInput.setTextSize(21);

        urlInput.setPadding(
                dp(20),
                dp(10),
                dp(20),
                dp(10)
        );

        urlInput.setBackground(
                createInputBackground()
        );

        root.addView(
                urlInput,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(72)
                )
        );

        // =================================================
        // JUST PLAYER
        // =================================================

        Button justPlayer =
                makeButton(
                        "▶   PLAY IN JUST PLAYER"
                );

        LinearLayout.LayoutParams justParams =
                fullParams();

        justParams.height =
                dp(68);

        justParams.topMargin =
                dp(15);

        root.addView(
                justPlayer,
                justParams
        );

        justPlayer.setOnClickListener(
                v -> playCurrentInJustPlayer()
        );

        // =================================================
        // CHOOSE PLAYER
        // =================================================

        Button choosePlayer =
                makeButton(
                        "🎬   CHOOSE VIDEO PLAYER"
                );

        LinearLayout.LayoutParams chooseParams =
                fullParams();

        chooseParams.height =
                dp(68);

        chooseParams.topMargin =
                dp(10);

        root.addView(
                choosePlayer,
                chooseParams
        );

        choosePlayer.setOnClickListener(
                v -> choosePlayerForCurrentUrl()
        );

        // =================================================
        // ADD FAVOURITE
        // =================================================

        Button addFavourite =
                makeButton(
                        "☆   ADD CURRENT URL TO FAVOURITES"
                );

        LinearLayout.LayoutParams favouriteParams =
                fullParams();

        favouriteParams.height =
                dp(62);

        favouriteParams.topMargin =
                dp(10);

        root.addView(
                addFavourite,
                favouriteParams
        );

        addFavourite.setOnClickListener(
                v -> addCurrentToFavourites()
        );

        // =================================================
        // FAVOURITES
        // =================================================

        TextView favTitle =
                sectionTitle(
                        "⭐  FAVOURITES"
                );

        LinearLayout.LayoutParams favTitleParams =
                fullParams();

        favTitleParams.topMargin =
                dp(38);

        favTitleParams.bottomMargin =
                dp(12);

        root.addView(
                favTitle,
                favTitleParams
        );

        favouritesSearch =
                createSearchBox(
                        "🔍  Search favourites by name or URL..."
                );

        root.addView(
                favouritesSearch,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(62)
                )
        );

        favouritesSearch.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {
                        refreshFavourites();
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s
                    ) {
                    }
                }
        );

        LinearLayout favouriteSort =
                createSortBar(true);

        root.addView(
                favouriteSort,
                fullParams()
        );

        favouritesLayout =
                new LinearLayout(this);

        favouritesLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        favouritesLayout.setBackgroundColor(BLACK);

        LinearLayout.LayoutParams favListParams =
                fullParams();

        favListParams.topMargin =
                dp(10);

        root.addView(
                favouritesLayout,
                favListParams
        );

        Button clearFav =
                makeButton(
                        "🧹   CLEAR ALL FAVOURITES"
                );

        LinearLayout.LayoutParams clearFavParams =
                fullParams();

        clearFavParams.height =
                dp(58);

        clearFavParams.topMargin =
                dp(12);

        root.addView(
                clearFav,
                clearFavParams
        );

        clearFav.setOnClickListener(
                v -> confirmClearFavourites()
        );

        // =================================================
        // HISTORY
        // =================================================

        TextView historyTitle =
                sectionTitle(
                        "🕘  LAST-USED HISTORY"
                );

        LinearLayout.LayoutParams historyTitleParams =
                fullParams();

        historyTitleParams.topMargin =
                dp(42);

        historyTitleParams.bottomMargin =
                dp(12);

        root.addView(
                historyTitle,
                historyTitleParams
        );

        historySearch =
                createSearchBox(
                        "🔍  Search history by name or URL..."
                );

        root.addView(
                historySearch,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(62)
                )
        );

        historySearch.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {
                        refreshHistory();
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s
                    ) {
                    }
                }
        );

        LinearLayout historySortBar =
                createSortBar(false);

        root.addView(
                historySortBar,
                fullParams()
        );

        historyLayout =
                new LinearLayout(this);

        historyLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        historyLayout.setBackgroundColor(BLACK);

        LinearLayout.LayoutParams historyListParams =
                fullParams();

        historyListParams.topMargin =
                dp(10);

        root.addView(
                historyLayout,
                historyListParams
        );

        Button clearHistory =
                makeButton(
                        "🧹   CLEAR ALL HISTORY"
                );

        LinearLayout.LayoutParams clearHistoryParams =
                fullParams();

        clearHistoryParams.height =
                dp(58);

        clearHistoryParams.topMargin =
                dp(12);

        root.addView(
                clearHistory,
                clearHistoryParams
        );

        clearHistory.setOnClickListener(
                v -> confirmClearHistory()
        );

        setContentView(scrollView);

        urlInput.requestFocus();
    }

    private EditText createSearchBox(String hint) {

        EditText search =
                new EditText(this);

        search.setHint(hint);

        search.setHintTextColor(
                Color.rgb(115, 115, 115)
        );

        search.setTextColor(WHITE);
        search.setSingleLine(true);
        search.setTextSize(18);

        search.setPadding(
                dp(18),
                dp(8),
                dp(18),
                dp(8)
        );

        search.setBackground(
                createInputBackground()
        );

        return search;
    }

    private LinearLayout createSortBar(
            boolean favourites
    ) {

        LinearLayout bar =
                new LinearLayout(this);

        bar.setOrientation(
                LinearLayout.HORIZONTAL
        );

        bar.setGravity(
                Gravity.CENTER_VERTICAL
        );

        Button newest =
                makeButton("NEWEST");

        Button oldest =
                makeButton("OLDEST");

        Button az =
                makeButton("A-Z");

        Button za =
                makeButton("Z-A");

        bar.addView(
                newest,
                buttonWeightParams()
        );

        bar.addView(
                oldest,
                buttonWeightParams()
        );

        bar.addView(
                az,
                buttonWeightParams()
        );

        bar.addView(
                za,
                buttonWeightParams()
        );

        newest.setOnClickListener(v -> {

            if (favourites) {

                favouritesSort =
                        SORT_NEWEST;

                refreshFavourites();

            } else {

                historySort =
                        SORT_NEWEST;

                refreshHistory();
            }
        });

        oldest.setOnClickListener(v -> {

            if (favourites) {

                favouritesSort =
                        SORT_OLDEST;

                refreshFavourites();

            } else {

                historySort =
                        SORT_OLDEST;

                refreshHistory();
            }
        });

        az.setOnClickListener(v -> {

            if (favourites) {

                favouritesSort =
                        SORT_AZ;

                refreshFavourites();

            } else {

                historySort =
                        SORT_AZ;

                refreshHistory();
            }
        });

        za.setOnClickListener(v -> {

            if (favourites) {

                favouritesSort =
                        SORT_ZA;

                refreshFavourites();

            } else {

                historySort =
                        SORT_ZA;

                refreshHistory();
            }
        });

        newest.setNextFocusRightId(
                oldest.getId()
        );

        oldest.setNextFocusLeftId(
                newest.getId()
        );

        oldest.setNextFocusRightId(
                az.getId()
        );

        az.setNextFocusLeftId(
                oldest.getId()
        );

        az.setNextFocusRightId(
                za.getId()
        );

        za.setNextFocusLeftId(
                az.getId()
        );

        return bar;
    }

    private String getCurrentUrl() {

        return urlInput
                .getText()
                .toString()
                .trim();
    }

    private void playCurrentInJustPlayer() {

        String url =
                getCurrentUrl();

        if (url.isEmpty()) {

            showMessage(
                    "Please enter a video URL"
            );

            return;
        }

        addHistory(url);
        openInJustPlayerFresh(url);
    }

    private void choosePlayerForCurrentUrl() {

        String url =
                getCurrentUrl();

        if (url.isEmpty()) {

            showMessage(
                    "Please enter a video URL"
            );

            return;
        }

        addHistory(url);
        openPlayerChooserFresh(url);
    }

    private void addCurrentToFavourites() {

        String url =
                getCurrentUrl();

        if (url.isEmpty()) {

            showMessage(
                    "Enter a URL first"
            );

            return;
        }

        addFavourite(url);
    }

    private void openInJustPlayerFresh(
            String url
    ) {

        try {

            Intent intent =
                    new Intent(
                            Intent.ACTION_VIEW
                    );

            intent.setDataAndType(
                    Uri.parse(url),
                    "video/*"
            );

            intent.setPackage(
                    JUST_PLAYER_PACKAGE
            );

            intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
            );

            intent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            );

            startActivity(intent);

        } catch (Exception e) {

            try {

                Intent fallback =
                        new Intent(
                                Intent.ACTION_VIEW
                        );

                fallback.setDataAndType(
                        Uri.parse(url),
                        "video/*"
                );

                fallback.setPackage(
                        JUST_PLAYER_PACKAGE
                );

                fallback.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                );

                startActivity(fallback);

            } catch (Exception ignored) {

                showMessage(
                        "Just Player is not installed"
                );
            }
        }
    }

    private void openPlayerChooserFresh(
            String url
    ) {

        try {

            Intent videoIntent =
                    new Intent(
                            Intent.ACTION_VIEW
                    );

            videoIntent.setDataAndType(
                    Uri.parse(url),
                    "video/*"
            );

            videoIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
            );

            videoIntent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            );

            Intent chooser =
                    Intent.createChooser(
                            videoIntent,
                            "Choose Video Player"
                    );

            startActivity(chooser);

        } catch (Exception e) {

            showMessage(
                    "No compatible video player found"
            );
        }
    }

    private void addHistory(
            String url
    ) {

        List<VideoItem> history =
                getItems(HISTORY);

        removeUrl(
                history,
                url
        );

        VideoItem item =
                createItem(url);

        item.timestamp =
                System.currentTimeMillis();

        history.add(
                0,
                item
        );

        saveItems(
                HISTORY,
                history
        );

        refreshHistory();
    }

    private void refreshHistory() {

        if (historyLayout == null)
            return;

        historyLayout.removeAllViews();

        List<VideoItem> history =
                getItems(HISTORY);

        String query = "";

        if (historySearch != null) {

            query =
                    historySearch
                            .getText()
                            .toString()
                            .trim()
                            .toLowerCase(
                                    Locale.getDefault()
                            );
        }

        List<VideoItem> filtered =
                filterItems(
                        history,
                        query
                );

        sortItems(
                filtered,
                historySort
        );

        if (filtered.isEmpty()) {

            addEmptyText(
                    historyLayout,
                    query.isEmpty()
                            ? "No recently used videos"
                            : "No matching history"
            );

            return;
        }

        for (VideoItem item : filtered) {

            addVideoRow(
                    historyLayout,
                    item,
                    false
            );
        }
    }

    private void addFavourite(
            String url
    ) {

        List<VideoItem> favourites =
                getItems(FAVOURITES);

        if (containsUrl(
                favourites,
                url
        )) {

            showMessage(
                    "Already in favourites"
            );

            return;
        }

        VideoItem item =
                createItem(url);

        item.timestamp =
                System.currentTimeMillis();

        favourites.add(
                0,
                item
        );

        saveItems(
                FAVOURITES,
                favourites
        );

        refreshFavourites();

        showMessage(
                "⭐ Added to favourites"
        );
    }

    private void removeFavourite(
            String url
    ) {

        List<VideoItem> favourites =
                getItems(FAVOURITES);

        removeUrl(
                favourites,
                url
        );

        saveItems(
                FAVOURITES,
                favourites
        );

        refreshFavourites();

        showMessage(
                "Removed from favourites"
        );
    }

    private void refreshFavourites() {

        if (favouritesLayout == null)
            return;

        favouritesLayout.removeAllViews();

        List<VideoItem> favourites =
                getItems(FAVOURITES);

        String query = "";

        if (favouritesSearch != null) {

            query =
                    favouritesSearch
                            .getText()
                            .toString()
                            .trim()
                            .toLowerCase(
                                    Locale.getDefault()
                            );
        }

        List<VideoItem> filtered =
                filterItems(
                        favourites,
                        query
                );

        sortItems(
                filtered,
                favouritesSort
        );

        if (filtered.isEmpty()) {

            addEmptyText(
                    favouritesLayout,
                    query.isEmpty()
                            ? "No favourite videos yet"
                            : "No matching favourites"
            );

            return;
        }

        for (VideoItem item : filtered) {

            addVideoRow(
                    favouritesLayout,
                    item,
                    true
            );
        }
    }

    private List<VideoItem> filterItems(
            List<VideoItem> source,
            String query
    ) {

        List<VideoItem> result =
                new ArrayList<>();

        if (query.isEmpty()) {

            result.addAll(source);

            return result;
        }

        for (VideoItem item : source) {

            String name =
                    item.fileName
                            .toLowerCase(
                                    Locale.getDefault()
                            );

            String url =
                    item.url
                            .toLowerCase(
                                    Locale.getDefault()
                            );

            if (name.contains(query)
                    || url.contains(query)) {

                result.add(item);
            }
        }

        return result;
    }

    private void sortItems(
            List<VideoItem> items,
            int sortMode
    ) {

        if (sortMode == SORT_NEWEST) {

            Collections.sort(
                    items,
                    (a, b) ->
                            Long.compare(
                                    b.timestamp,
                                    a.timestamp
                            )
            );

        } else if (sortMode == SORT_OLDEST) {

            Collections.sort(
                    items,
                    (a, b) ->
                            Long.compare(
                                    a.timestamp,
                                    b.timestamp
                            )
            );

        } else if (sortMode == SORT_AZ) {

            Collections.sort(
                    items,
                    new Comparator<VideoItem>() {

                        @Override
                        public int compare(
                                VideoItem a,
                                VideoItem b
                        ) {

                            return a.fileName
                                    .toLowerCase(
                                            Locale.getDefault()
                                    )
                                    .compareTo(
                                            b.fileName
                                                    .toLowerCase(
                                                            Locale.getDefault()
                                                    )
                                    );
                        }
                    }
            );

        } else {

            Collections.sort(
                    items,
                    new Comparator<VideoItem>() {

                        @Override
                        public int compare(
                                VideoItem a,
                                VideoItem b
                        ) {

                            return b.fileName
                                    .toLowerCase(
                                            Locale.getDefault()
                                    )
                                    .compareTo(
                                            a.fileName
                                                    .toLowerCase(
                                                            Locale.getDefault()
                                                    )
                                    );
                        }
                    }
            );
        }
    }

    private void addVideoRow(
            LinearLayout parent,
            VideoItem item,
            boolean favouriteSection
    ) {

        LinearLayout container =
                new LinearLayout(this);

        container.setOrientation(
                LinearLayout.VERTICAL
        );

        container.setPadding(
                dp(18),
                dp(16),
                dp(18),
                dp(16)
        );

        GradientDrawable card =
                new GradientDrawable();

        card.setColor(CARD);
        card.setCornerRadius(dp(14));

        card.setStroke(
                dp(1),
                Color.rgb(48, 48, 48)
        );

        container.setBackground(card);

        TextView filename =
                makeText(
                        "🎬  " + item.fileName,
                        20
                );

        filename.setTypeface(
                null,
                Typeface.BOLD
        );

        filename.setMaxLines(2);

        filename.setEllipsize(
                android.text.TextUtils.TruncateAt.END
        );

        container.addView(
                filename,
                fullParams()
        );

        TextView date =
                makeText(
                        "🕘  " +
                                formatDate(
                                        item.timestamp
                                ),
                        15
                );

        date.setTextColor(GREY);

        LinearLayout.LayoutParams dateParams =
                fullParams();

        dateParams.topMargin =
                dp(5);

        container.addView(
                date,
                dateParams
        );

        TextView urlText =
                makeText(
                        item.url,
                        13
                );

        urlText.setTextColor(
                Color.rgb(
                        125,
                        125,
                        125
                )
        );

        urlText.setMaxLines(1);

        urlText.setEllipsize(
                android.text.TextUtils.TruncateAt.MIDDLE
        );

        LinearLayout.LayoutParams urlParams =
                fullParams();

        urlParams.topMargin =
                dp(5);

        urlParams.bottomMargin =
                dp(8);

        container.addView(
                urlText,
                urlParams
        );

        LinearLayout buttons =
                new LinearLayout(this);

        buttons.setOrientation(
                LinearLayout.HORIZONTAL
        );

        buttons.setGravity(
                Gravity.CENTER_VERTICAL
        );

        Button choose =
                makeButton(
                        "🎬 PLAYER"
                );

        buttons.addView(
                choose,
                buttonWeightParams()
        );

        choose.setOnClickListener(v -> {

            urlInput.setText(
                    item.url
            );

            addHistory(
                    item.url
            );

            openPlayerChooserFresh(
                    item.url
            );
        });

        Button rename =
                makeButton(
                        "✏ RENAME"
                );

        buttons.addView(
                rename,
                buttonWeightParams()
        );

        rename.setOnClickListener(
                v -> showRenameDialog(
                        item,
                        favouriteSection
                )
        );

        Button favourite =
                makeButton(
                        favouriteSection
                                ? "★"
                                : "☆"
                );

        LinearLayout.LayoutParams smallParams =
                new LinearLayout.LayoutParams(
                        dp(65),
                        dp(60)
                );

        smallParams.setMargins(
                dp(4),
                dp(4),
                dp(4),
                dp(4)
        );

        buttons.addView(
                favourite,
                smallParams
        );

        favourite.setOnClickListener(v -> {

            if (favouriteSection) {

                removeFavourite(
                        item.url
                );

            } else {

                addFavourite(
                        item.url
                );
            }
        });

        Button delete =
                makeButton(
                        "🗑"
                );

        buttons.addView(
                delete,
                smallParams
        );

        delete.setOnClickListener(v -> {

            if (favouriteSection) {

                confirmDeleteFavourite(
                        item.url
                );

            } else {

                confirmDeleteHistory(
                        item.url
                );
            }
        });

        container.addView(
                buttons,
                fullParams()
        );

        choose.setNextFocusRightId(
                rename.getId()
        );

        rename.setNextFocusLeftId(
                choose.getId()
        );

        rename.setNextFocusRightId(
                favourite.getId()
        );

        favourite.setNextFocusLeftId(
                rename.getId()
        );

        favourite.setNextFocusRightId(
                delete.getId()
        );

        delete.setNextFocusLeftId(
                favourite.getId()
        );

        LinearLayout.LayoutParams containerParams =
                fullParams();

        containerParams.bottomMargin =
                dp(14);

        parent.addView(
                container,
                containerParams
        );
    }

    private void showRenameDialog(
            VideoItem item,
            boolean favouriteSection
    ) {

        final EditText input =
                new EditText(this);

        input.setSingleLine(true);
        input.setText(item.fileName);
        input.setTextColor(WHITE);
        input.setTextSize(18);
        input.setSelectAllOnFocus(true);

        input.setPadding(
                dp(16),
                dp(10),
                dp(16),
                dp(10)
        );

        input.setBackground(
                createInputBackground()
        );

        LinearLayout wrapper =
                new LinearLayout(this);

        wrapper.setPadding(
                dp(22),
                dp(5),
                dp(22),
                dp(5)
        );

        wrapper.addView(
                input,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(60)
                )
        );

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle(
                                "Rename Video"
                        )
                        .setMessage(
                                "Enter a custom name for this video."
                        )
                        .setView(wrapper)
                        .setNegativeButton(
                                "CANCEL",
                                null
                        )
                        .setPositiveButton(
                                "SAVE",
                                null
                        )
                        .create();

        dialog.setOnShowListener(d -> {

            Button save =
                    dialog.getButton(
                            AlertDialog.BUTTON_POSITIVE
                    );

            save.setOnClickListener(v -> {

                String newName =
                        input.getText()
                                .toString()
                                .trim();

                if (newName.isEmpty()) {

                    Toast.makeText(
                            this,
                            "Name cannot be empty",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                renameItem(
                        item.url,
                        newName
                );

                dialog.dismiss();
            });

            input.requestFocus();

            input.postDelayed(() -> {

                InputMethodManager imm =
                        (InputMethodManager)
                                getSystemService(
                                        INPUT_METHOD_SERVICE
                                );

                if (imm != null) {

                    imm.showSoftInput(
                            input,
                            InputMethodManager.SHOW_IMPLICIT
                    );
                }

            }, 200);
        });

        dialog.show();
    }

    private void renameItem(
            String url,
            String newName
    ) {

        boolean changed = false;

        List<VideoItem> history =
                getItems(HISTORY);

        for (VideoItem item : history) {

            if (item.url.equals(url)) {

                item.fileName =
                        newName;

                changed = true;
            }
        }

        if (changed) {

            saveItems(
                    HISTORY,
                    history
            );
        }

        List<VideoItem> favourites =
                getItems(FAVOURITES);

        for (VideoItem item : favourites) {

            if (item.url.equals(url)) {

                item.fileName =
                        newName;

                changed = true;
            }
        }

        if (changed) {

            saveItems(
                    FAVOURITES,
                    favourites
            );
        }

        refreshHistory();
        refreshFavourites();

        showMessage(
                "✏ Name updated"
        );
    }

    private void confirmDeleteHistory(
            String url
    ) {

        new AlertDialog.Builder(this)
                .setTitle(
                        "Remove from History?"
                )
                .setMessage(
                        "This video will be removed from your history."
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "REMOVE",
                        (dialog, which) ->
                                deleteHistory(url)
                )
                .show();
    }

    private void confirmDeleteFavourite(
            String url
    ) {

        new AlertDialog.Builder(this)
                .setTitle(
                        "Remove Favourite?"
                )
                .setMessage(
                        "This video will be removed from favourites."
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "REMOVE",
                        (dialog, which) ->
                                removeFavourite(url)
                )
                .show();
    }

    private void confirmClearHistory() {

        List<VideoItem> items =
                getItems(HISTORY);

        if (items.isEmpty()) {

            showMessage(
                    "History is already empty"
            );

            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(
                        "Clear All History?"
                )
                .setMessage(
                        "All saved history entries will be permanently removed."
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "CLEAR ALL",
                        (dialog, which) ->
                                clearHistory()
                )
                .show();
    }

    private void confirmClearFavourites() {

        List<VideoItem> items =
                getItems(FAVOURITES);

        if (items.isEmpty()) {

            showMessage(
                    "Favourites are already empty"
            );

            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(
                        "Clear All Favourites?"
                )
                .setMessage(
                        "All favourite videos will be permanently removed."
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "CLEAR ALL",
                        (dialog, which) ->
                                clearFavourites()
                )
                .show();
    }

    private void deleteHistory(
            String url
    ) {

        List<VideoItem> history =
                getItems(HISTORY);

        removeUrl(
                history,
                url
        );

        saveItems(
                HISTORY,
                history
        );

        refreshHistory();

        showMessage(
                "Removed from history"
        );
    }

    private void clearHistory() {

        prefs.edit()
                .remove(HISTORY)
                .apply();

        refreshHistory();

        showMessage(
                "History cleared"
        );
    }

    private void clearFavourites() {

        prefs.edit()
                .remove(FAVOURITES)
                .apply();

        refreshFavourites();

        showMessage(
                "Favourites cleared"
        );
    }

    private VideoItem createItem(
            String url
    ) {

        VideoItem item =
                new VideoItem();

        item.url = url;
        item.fileName =
                getFileName(url);

        item.timestamp =
                System.currentTimeMillis();

        return item;
    }

    private String getFileName(
            String url
    ) {

        try {

            Uri uri =
                    Uri.parse(url);

            String last =
                    uri.getLastPathSegment();

            if (last != null
                    && !last.isEmpty()) {

                String decoded =
                        decode(last);

                if (!decoded.isEmpty()) {

                    return decoded;
                }
            }

        } catch (Exception ignored) {
        }

        try {

            String clean =
                    url.split("\\?")[0];

            int slash =
                    clean.lastIndexOf('/');

            if (slash >= 0
                    && slash <
                    clean.length() - 1) {

                return decode(
                        clean.substring(
                                slash + 1
                        )
                );
            }

        } catch (Exception ignored) {
        }

        return "Video";
    }

    private String decode(
            String value
    ) {

        try {

            return URLDecoder.decode(
                    value,
                    "UTF-8"
            );

        } catch (Exception e) {

            return value;
        }
    }

    private String formatDate(
            long timestamp
    ) {

        SimpleDateFormat format =
                new SimpleDateFormat(
                        "dd MMM yyyy  •  hh:mm a",
                        Locale.getDefault()
                );

        return format.format(
                new Date(timestamp)
        );
    }

    private void saveItems(
            String key,
            List<VideoItem> items
    ) {

        StringBuilder data =
                new StringBuilder();

        for (VideoItem item : items) {

            if (data.length() > 0) {

                data.append("\n");
            }

            String record =
                    item.timestamp
                            + "\t"
                            + item.fileName
                            + "\t"
                            + item.url;

            String encoded =
                    android.util.Base64
                            .encodeToString(
                                    record.getBytes(
                                            StandardCharsets.UTF_8
                                    ),
                                    android.util.Base64.NO_WRAP
                            );

            data.append(encoded);
        }

        prefs.edit()
                .putString(
                        key,
                        data.toString()
                )
                .apply();
    }

    private List<VideoItem> getItems(
            String key
    ) {

        String data =
                prefs.getString(
                        key,
                        ""
                );

        List<VideoItem> result =
                new ArrayList<>();

        if (data.isEmpty()) {

            return result;
        }

        String[] records =
                data.split("\n");

        for (String encoded : records) {

            try {

                byte[] decoded =
                        android.util.Base64.decode(
                                encoded,
                                android.util.Base64.NO_WRAP
                        );

                String record =
                        new String(
                                decoded,
                                StandardCharsets.UTF_8
                        );

                String[] parts =
                        record.split(
                                "\t",
                                3
                        );

                if (parts.length >= 3) {

                    VideoItem item =
                            new VideoItem();

                    item.timestamp =
                            Long.parseLong(
                                    parts[0]
                            );

                    item.fileName =
                            parts[1];

                    item.url =
                            parts[2];

                    result.add(item);
                }

            } catch (Exception ignored) {
            }
        }

        return result;
    }

    private boolean containsUrl(
            List<VideoItem> items,
            String url
    ) {

        for (VideoItem item : items) {

            if (item.url.equals(url)) {

                return true;
            }
        }

        return false;
    }

    private void removeUrl(
            List<VideoItem> items,
            String url
    ) {

        for (int i = items.size() - 1;
             i >= 0;
             i--) {

            if (items.get(i)
                    .url
                    .equals(url)) {

                items.remove(i);
            }
        }
    }

    private void addEmptyText(
            LinearLayout parent,
            String text
    ) {

        TextView empty =
                makeText(
                        text,
                        18
                );

        empty.setTextColor(GREY);

        empty.setGravity(
                Gravity.CENTER
        );

        LinearLayout.LayoutParams params =
                fullParams();

        params.height =
                dp(70);

        parent.addView(
                empty,
                params
        );
    }

    private void showMessage(
            String message
    ) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    private static class VideoItem {

        String url;
        String fileName;
        long timestamp;
    }
}
