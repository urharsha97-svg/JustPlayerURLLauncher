# Stream Link — TV Receiver + Mobile Sender

This repository contains two separate Android apps:

- **Stream Link** — Android TV receiver (`com.justplayer.urllauncher`)
- **Stream Link Sender** — Android phone sender (`com.streamlink.sender`)

They intentionally use different application IDs, so installing the phone sender cannot conflict with the TV receiver.

## Transfer

Both apps use the same framed URL protocol: UTF-8 payload bytes, payload length, SHA-256 digest, and an ACK. Bluetooth and Wi-Fi/TCP transfers retry up to three times when the receiver does not acknowledge the payload.

Wi-Fi discovery uses UDP broadcast on port 38766 and URL transfer uses TCP port 38765. Bluetooth uses the same RFCOMM service UUID on both apps.

## Build

GitHub Actions builds both debug APKs. Download the artifacts from the workflow run:

- `stream-link-tv-debug`
- `stream-link-sender-debug`

## Install

Install **Stream Link** on the Android TV and **Stream Link Sender** on the phone. Do not install the TV APK on the phone.

A debug APK installed outside Google Play may still trigger a Google Play Protect scan prompt; that is controlled by Android/Google Play Protect and cannot be removed by an app's package configuration.
