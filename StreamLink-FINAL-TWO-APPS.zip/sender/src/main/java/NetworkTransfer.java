package com.streamlink.sender;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

public final class NetworkTransfer {
    public static final int TCP_PORT = 38765;
    public static final int UDP_PORT = 38766;
    private static final int TIMEOUT_MS = 1200;

    private NetworkTransfer() {}

    public static boolean sendUrl(String host, String url) {
        for (int attempt = 0; attempt < 3; attempt++) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host, TCP_PORT), 2500);
                socket.setSoTimeout(3000);
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                DataInputStream in = new DataInputStream(socket.getInputStream());
                UrlTransferProtocol.write(out, url);
                return in.readByte() == UrlTransferProtocol.ACK_OK;
            } catch (Exception ignored) {}
        }
        return false;
    }

    public static List<NetworkDevice> discoverTvs() {
        List<NetworkDevice> result = new ArrayList<>();
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            socket.setSoTimeout(TIMEOUT_MS);
            byte[] request = "SLINK_DISCOVER_1".getBytes(java.nio.charset.StandardCharsets.US_ASCII);
            DatagramPacket packet = new DatagramPacket(request, request.length,
                    InetAddress.getByName("255.255.255.255"), UDP_PORT);
            socket.send(packet);

            long end = System.currentTimeMillis() + 1600;
            while (System.currentTimeMillis() < end) {
                try {
                    byte[] buf = new byte[512];
                    DatagramPacket response = new DatagramPacket(buf, buf.length);
                    socket.receive(response);
                    String text = new String(response.getData(), response.getOffset(), response.getLength(),
                            java.nio.charset.StandardCharsets.UTF_8);
                    if (text.startsWith("SLINK_TV_1|")) {
                        String[] parts = text.split("\\|", 2);
                        String name = parts.length > 1 && !parts[1].isEmpty() ? parts[1] : "Stream Link TV";
                        String host = response.getAddress().getHostAddress();
                        boolean exists = false;
                        for (NetworkDevice d : result) if (d.host.equals(host)) exists = true;
                        if (!exists) result.add(new NetworkDevice(name, host));
                    }
                } catch (SocketTimeoutException ignored) {}
            }
        } catch (Exception ignored) {}
        return result;
    }
}
