package com.streamlink.sender;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SenderActivity extends Activity {

    private static final int REQUEST_BLUETOOTH = 701;
    private static final int REQUEST_BLUETOOTH_SCAN = 702;

    private EditText urlInput;
    private EditText ipInput;
    private TextView status;
    private Button bluetoothButton;
    private Button lanButton;

    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int CARD = Color.rgb(17, 17, 17);
    private static final int CARD_2 = Color.rgb(25, 25, 25);
    private static final int FOCUS = Color.rgb(35, 75, 125);
    private static final int FOCUS_BORDER = Color.rgb(80, 160, 255);
    private static final int WHITE = Color.rgb(245, 245, 245);
    private static final int GREY = Color.rgb(165, 165, 165);
    private static final int BLUE = Color.rgb(120, 210, 255);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        buildUi();
        handleIncomingIntent(getIntent());

        if (Build.VERSION.SDK_INT >= 31 &&
                (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                 checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN},
                    REQUEST_BLUETOOTH
            );
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) &&
                "text/plain".equals(intent.getType())) {
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null && text.length() > 0 && urlInput != null) {
                urlInput.setText(text.toString());
                urlInput.setSelection(urlInput.length());
            }
        }
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);
        b.setPadding(dp(8), dp(4), dp(8), dp(4));

        android.graphics.drawable.StateListDrawable states =
                new android.graphics.drawable.StateListDrawable();

        android.graphics.drawable.GradientDrawable normal =
                new android.graphics.drawable.GradientDrawable();
        normal.setColor(CARD_2);
        normal.setCornerRadius(dp(10));
        normal.setStroke(dp(1), Color.rgb(45,45,45));

        android.graphics.drawable.GradientDrawable focused =
                new android.graphics.drawable.GradientDrawable();
        focused.setColor(FOCUS);
        focused.setCornerRadius(dp(10));
        focused.setStroke(dp(3), FOCUS_BORDER);

        states.addState(
                new int[]{android.R.attr.state_focused},
                focused
        );
        states.addState(new int[]{}, normal);
        b.setBackground(states);
        return b;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(115,115,115));
        e.setTextColor(WHITE);
        e.setSingleLine(true);
        e.setTextSize(19);
        e.setPadding(dp(18), dp(8), dp(18), dp(8));

        android.graphics.drawable.GradientDrawable bg =
                new android.graphics.drawable.GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(50,50,50));
        e.setBackground(bg);
        return e;
    }

    private TextView label(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(WHITE);
        return t;
    }

    private void buildUi() {
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(35), dp(25), dp(35), dp(35));
        root.setBackgroundColor(BLACK);
        scroll.addView(root);

        TextView brand = label("STREAM LINK", 16);
        brand.setTextColor(BLUE);
        brand.setTypeface(null, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, full());

        TextView title = label("MOBILE URL SENDER", 32);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = full();
        tp.topMargin = dp(4);
        root.addView(title, tp);

        TextView sub = label(
                "Send an exact video URL to your Stream Link TV",
                17
        );
        sub.setTextColor(GREY);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = full();
        sp.topMargin = dp(8);
        sp.bottomMargin = dp(24);
        root.addView(sub, sp);

        urlInput = input("Paste video URL here");
        root.addView(urlInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(70)
        ));

        bluetoothButton = button("Bluetooth  •  SELECT PAIRED TV");
        LinearLayout.LayoutParams bp = full();
        bp.height = dp(65);
        bp.topMargin = dp(14);
        root.addView(bluetoothButton, bp);
        bluetoothButton.setOnClickListener(v -> sendBluetooth());

        ipInput = input("TV IP address (same Wi-Fi)");
        LinearLayout.LayoutParams ipp = full();
        ipp.height = dp(62);
        ipp.topMargin = dp(12);
        root.addView(ipInput, ipp);

        LinearLayout lanRow = new LinearLayout(this);
        lanRow.setOrientation(LinearLayout.HORIZONTAL);

        Button discover = button("DISCOVER TV");
        lanButton = button("SEND OVER WI-FI");

        lanRow.addView(discover, weightParams());
        lanRow.addView(lanButton, weightParams());
        LinearLayout.LayoutParams lrp = full();
        lrp.topMargin = dp(8);
        root.addView(lanRow, lrp);

        discover.setOnClickListener(v -> discoverTv());
        lanButton.setOnClickListener(v -> sendLan());

        Button share = button("ANDROID SHARE");
        LinearLayout.LayoutParams sh = full();
        sh.height = dp(62);
        sh.topMargin = dp(12);
        root.addView(share, sh);
        share.setOnClickListener(v -> shareUrl());

        status = label("Ready", 16);
        status.setTextColor(GREY);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams st = full();
        st.topMargin = dp(18);
        root.addView(status, st);

        TextView note = label(
                "Bluetooth works without Wi-Fi or internet. " +
                "Wi-Fi transfer requires phone and TV on the same local network.",
                14
        );
        note.setTextColor(GREY);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = full();
        np.topMargin = dp(14);
        root.addView(note, np);

        setContentView(scroll);
        urlInput.requestFocus();
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, dp(60), 1f
        );
        p.setMargins(dp(4), dp(2), dp(4), dp(2));
        return p;
    }

    private String url() {
        return urlInput.getText().toString();
    }

    private void sendBluetooth() {
        String url = url();
        if (url.trim().isEmpty()) {
            toast("Paste a URL first");
            return;
        }

        if (Build.VERSION.SDK_INT >= 31 &&
                (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                 checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN},
                    REQUEST_BLUETOOTH
            );
            return;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            toast("This phone does not support Bluetooth");
            return;
        }

        if (!adapter.isEnabled()) {
            try {
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            } catch (Exception ignored) {}
            toast("Turn on Bluetooth, then press SEND again");
            return;
        }

        Set<BluetoothDevice> bonded =
                BluetoothTransfer.getBondedDevices(this);

        if (bonded.isEmpty()) {
            toast("Pair the phone with the TV in Bluetooth settings first");
            return;
        }

        List<BluetoothDevice> devices = new ArrayList<>(bonded);
        String[] names = new String[devices.size()];

        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String name;
            try {
                name = d.getName();
            } catch (Exception e) {
                name = "Paired device";
            }
            if (name == null || name.trim().isEmpty()) name = "Paired device";
            names[i] = name;
        }

        new AlertDialog.Builder(this)
                .setTitle("Select paired TV")
                .setItems(names, (dialog, which) ->
                        actuallySendBluetooth(devices.get(which), url))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void actuallySendBluetooth(
            BluetoothDevice device,
            String url
    ) {
        status.setText("Bluetooth: sending...");
        new Thread(() -> {
            try {
                BluetoothTransfer.sendToDevice(device, url, 3);
                runOnUiThread(() ->
                        status.setText("✓ Bluetooth: URL sent successfully")
                );
            } catch (Exception e) {
                runOnUiThread(() ->
                        status.setText("✕ Bluetooth failed: " + safeMessage(e))
                );
            }
        }, "StreamLink-BluetoothSender").start();
    }

    private void discoverTv() {
        status.setText("Searching for Stream Link TVs...");
        new Thread(() -> {
            try {
                List<LanTransfer.Device> devices =
                        LanTransfer.Discovery.find(this, 1800);

                runOnUiThread(() -> {
                    if (devices.isEmpty()) {
                        status.setText(
                                "No TV found. Enter the TV IP manually."
                        );
                        return;
                    }

                    String[] names = new String[devices.size()];
                    for (int i = 0; i < devices.size(); i++) {
                        names[i] = devices.get(i).toString();
                    }

                    new AlertDialog.Builder(this)
                            .setTitle("Stream Link TVs found")
                            .setItems(names, (dialog, which) -> {
                                ipInput.setText(devices.get(which).host);
                                status.setText(
                                        "TV selected: " +
                                                devices.get(which).host
                                );
                            })
                            .setNegativeButton("CANCEL", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() ->
                        status.setText("Discovery failed")
                );
            }
        }, "StreamLink-LanDiscovery").start();
    }

    private void sendLan() {
        String url = url();
        String host = ipInput.getText().toString().trim();

        if (url.trim().isEmpty()) {
            toast("Paste a URL first");
            return;
        }

        if (host.isEmpty()) {
            toast("Discover the TV or enter its IP address");
            return;
        }

        status.setText("Wi-Fi: sending...");
        new Thread(() -> {
            try {
                LanTransfer.send(host, url);
                runOnUiThread(() ->
                        status.setText("✓ Wi-Fi: URL sent successfully")
                );
            } catch (Exception e) {
                runOnUiThread(() ->
                        status.setText("✕ Wi-Fi failed: " + safeMessage(e))
                );
            }
        }, "StreamLink-LanSender").start();
    }

    private void shareUrl() {
        String url = url();
        if (url.trim().isEmpty()) {
            toast("Paste a URL first");
            return;
        }

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        send.setClipData(ClipData.newPlainText("Video URL", url));
        startActivity(Intent.createChooser(send, "Send URL to Stream Link"));
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return "connection error";
        return m;
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
