package com.streamlink.sender;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class BluetoothSender {
    public interface Callback { void onMessage(String message); }
    public static final UUID UUID_STREAM_LINK = UUID.fromString("7b1e8f40-8c36-4b1b-a9d5-3f8f7b3d7b11");

    private BluetoothSender() {}

    public static void chooseAndSend(Context context, String url, Callback callback) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) { callback.onMessage("Bluetooth is not available"); return; }
        if (!adapter.isEnabled()) { callback.onMessage("Turn Bluetooth on first"); return; }

        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            callback.onMessage("Bluetooth permission is required");
            return;
        }

        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        List<BluetoothDevice> devices = new ArrayList<>(bonded);
        if (devices.isEmpty()) { callback.onMessage("Pair the phone and TV in Bluetooth settings first"); return; }

        String[] names = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) names[i] = safeName(devices.get(i));

        new AlertDialog.Builder(context)
                .setTitle("Select paired TV")
                .setItems(names, (dialog, which) -> new Thread(() -> {
                    boolean ok = send(devices.get(which), url);
                    callback.onMessage(ok ? "✓ Bluetooth URL sent" : "✕ Bluetooth transfer failed");
                }).start())
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private static String safeName(BluetoothDevice d) {
        try { return d.getName() == null ? "Paired device" : d.getName(); }
        catch (Exception e) { return "Paired device"; }
    }

    private static boolean send(BluetoothDevice device, String url) {
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter != null) adapter.cancelDiscovery();
            } catch (Exception ignored) {}
            try (android.bluetooth.BluetoothSocket socket = device.createRfcommSocketToServiceRecord(UUID_STREAM_LINK)) {
                socket.connect();
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                DataInputStream in = new DataInputStream(socket.getInputStream());
                UrlTransferProtocol.write(out, url);
                return in.readByte() == UrlTransferProtocol.ACK_OK;
            } catch (Exception ignored) {}
        }
        return false;
    }
}
