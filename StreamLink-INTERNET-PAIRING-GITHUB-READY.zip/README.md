# Stream Link — Separate Sender + TV Receiver

This release contains **two independent Android apps**:

- **Stream Link Sender** — phone-first app, package `com.streamlink.sender`.
- **Stream Link** — Android TV receiver/Just Player launcher, package `com.justplayer.urllauncher` (preserved so it can update the existing TV app).

## Internet mode (different Wi-Fi)

The phone and TV do **not** need to be on the same Wi-Fi. Both only need Internet access. A small Cloudflare Durable Object relay is included in `relay/`.

### One-time setup
1. Deploy `relay/` with Wrangler.
2. Put the resulting HTTPS Worker URL into the TV's **Internet relay URL** field.
3. On TV press **PAIR / SHOW PHONE CODE**.
4. Enter that six-digit code once in **Stream Link Sender**, along with the same relay URL, and press **PAIR WITH TV**.
5. The phone saves the pairing. After that, every URL uses the saved connection; no repeated pairing is needed.

The TV keeps its identity and receiver token in its existing app preferences. The sender keeps its paired TV identity/token in its preferences. Temporary pairing codes expire quickly.

## URL integrity

URLs are converted to exact UTF-8 bytes, Base64 encoded for transport, and protected with SHA-256. The TV verifies the hash before accepting a URL and acknowledges successful receipt. The relay keeps only the current pending message and removes it after a successful ACK.

## Local Bluetooth/LAN

The existing Bluetooth and same-LAN paths are retained as fallbacks. Internet mode is the intended path when phone and TV are on different networks.

## GitHub Actions

The workflow builds two separate debug APK artifacts:
- `Stream-Link-Sender`
- `Stream-Link-TV`

## Final architecture
- `sender` is a separate phone-first app: **Stream Link Sender** (`com.streamlink.sender`).
- `tv` is the separate Android TV app: **Stream Link** (`com.justplayer.urllauncher`).
- Internet relay pairing is one-time. Sender stores the TV identity/token and sends later URLs without pairing again.
- TV keeps its identity/token and polls the relay while the receiver app is running; network changes are handled by retry/reconnect polling.
- History/Favourites rows now have a dedicated **JUST PLAYER** action before the generic **PLAYER** chooser.
- URL bytes are UTF-8 encoded and protected with length + SHA-256; the TV acknowledges successful receipt.
