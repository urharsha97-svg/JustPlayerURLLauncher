package com.streamlink.sender;

import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

public final class RelayClient {
    private final String base;
    public RelayClient(String baseUrl){ this.base=baseUrl.replaceAll("/+$",""); }
    private String post(String path,String json)throws Exception{return request("POST",path,json);}
    private String get(String path)throws Exception{return request("GET",path,null);}
    private String request(String method,String path,String body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(base+path).openConnection();
        c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(12000);
        c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
        if(body!=null){c.setDoOutput(true); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        String s=read(in); if(code<200||code>=300)throw new IOException("Relay HTTP "+code+": "+s); return s;
    }
    private static String read(InputStream in)throws Exception{if(in==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String x;while((x=r.readLine())!=null)b.append(x);return b.toString();}}
    public Pairing createPair()throws Exception{JSONObject j=new JSONObject(post("/pair/create","{}"));return new Pairing(j.getString("deviceId"),j.getString("deviceToken"),j.getString("code"));}
    public Paired claim(String code)throws Exception{JSONObject j=new JSONObject(post("/pair/claim",new JSONObject().put("code",code).toString()));return new Paired(j.getString("deviceId"),j.getString("senderToken"));}
    public boolean send(String deviceId,String token,String url)throws Exception{
        byte[] bytes=url.getBytes(StandardCharsets.UTF_8); String b64=Base64.encodeToString(bytes,Base64.NO_WRAP); String hash=hex(MessageDigest.getInstance("SHA-256").digest(bytes));
        JSONObject p=new JSONObject().put("token",token).put("payload",b64).put("length",bytes.length).put("sha256",hash);
        for(int i=0;i<3;i++){try{JSONObject r=new JSONObject(post("/send/"+URLEncoder.encode(deviceId,"UTF-8"),p.toString()));if(r.optBoolean("ok"))return true;}catch(Exception e){if(i==2)throw e;TimeUnit.MILLISECONDS.sleep(400L*(i+1));}}
        return false;
    }
    private static String hex(byte[] a){StringBuilder b=new StringBuilder();for(byte x:a)b.append(String.format("%02x",x));return b.toString();}
    public static final class Pairing{public final String deviceId,deviceToken,code;Pairing(String a,String b,String c){deviceId=a;deviceToken=b;code=c;}}
    public static final class Paired{public final String deviceId,senderToken;Paired(String a,String b){deviceId=a;senderToken=b;}}
}
