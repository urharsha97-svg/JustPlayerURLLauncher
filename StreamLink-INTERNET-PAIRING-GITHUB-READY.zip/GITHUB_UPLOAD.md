# Stream Link — GitHub upload

This is a two-module Android project:
- `:tv` — Android TV receiver
- `:sender` — Android phone sender

Required repository root structure:

```
.github/workflows/build.yml
relay/
sender/
tv/
build.gradle
settings.gradle
README.md
```

The workflow builds both debug APKs with Java 17 and Gradle 8.7.

Important: upload the *contents* of this ZIP into the repository root, not the ZIP file itself. Keep `.github/workflows/build.yml` at exactly that path.
