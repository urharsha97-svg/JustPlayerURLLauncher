export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const id = env.RELAY.getByName('global');
    return id.fetch(new Request(new URL(url.pathname + url.search, 'https://relay.internal'), request));
  }
};

export class RelayState {
  constructor(state) { this.state = state; }
  async fetch(request) {
    const url = new URL(request.url);
    try {
      if (request.method !== 'POST') return json({ok:false,error:'POST required'},405);
      const body = await request.json();
      if (url.pathname === '/pair/create') return this.createPair();
      if (url.pathname === '/pair/claim') return this.claim(String(body.code || ''));
      const m = url.pathname.match(/^\/(send|poll|ack)\/([^/]+)$/);
      if (!m) return json({ok:false,error:'not found'},404);
      const deviceId = decodeURIComponent(m[2]);
      const device = await this.state.storage.get('device:' + deviceId);
      if (!device) return json({ok:false,error:'unknown device'},404);
      if (m[1] === 'send') return this.send(deviceId, device, body);
      if (m[1] === 'poll') return this.poll(deviceId, device, body);
      return this.ack(deviceId, device, body);
    } catch (e) { return json({ok:false,error:String(e.message || e)},400); }
  }
  async createPair() {
    const deviceId = token(16), deviceToken = token(24), code = String(Math.floor(100000 + Math.random()*900000));
    const device = { deviceId, deviceToken, senderToken: null, code, message: null, createdAt: Date.now() };
    await this.state.storage.put('device:' + deviceId, device, {expirationTtl: 60*60*24*365});
    await this.state.storage.put('code:' + code, deviceId, {expirationTtl: 600});
    return json({ok:true,deviceId,deviceToken,code});
  }
  async claim(code) {
    if (!/^\d{6}$/.test(code)) return json({ok:false,error:'invalid code'},400);
    const deviceId = await this.state.storage.get('code:' + code);
    if (!deviceId) return json({ok:false,error:'code expired or invalid'},404);
    const device = await this.state.storage.get('device:' + deviceId);
    if (!device) return json({ok:false,error:'device unavailable'},404);
    const senderToken = token(24); device.senderToken = senderToken; device.code = null;
    await this.state.storage.put('device:' + deviceId, device, {expirationTtl: 60*60*24*365});
    await this.state.storage.delete('code:' + code);
    return json({ok:true,deviceId,senderToken});
  }
  auth(device, tokenValue, wanted) { return typeof tokenValue === 'string' && tokenValue.length > 0 && tokenValue === device[wanted]; }
  async send(deviceId, device, body) {
    if (!this.auth(device, body.token, 'senderToken')) return json({ok:false,error:'unauthorized'},401);
    if (typeof body.payload !== 'string' || typeof body.sha256 !== 'string' || !Number.isInteger(body.length) || body.length < 0 || body.length > 2000000) return json({ok:false,error:'bad payload'},400);
    const messageId = token(12);
    device.message = { messageId, payload: body.payload, length: body.length, sha256: body.sha256, createdAt: Date.now() };
    await this.state.storage.put('device:' + deviceId, device, {expirationTtl: 60*60*24*365});
    return json({ok:true,messageId});
  }
  async poll(deviceId, device, body) {
    if (!this.auth(device, body.token, 'deviceToken')) return json({ok:false,error:'unauthorized'},401);
    if (!device.message) return json({ok:true});
    return json({ok:true,messageId:device.message.messageId,payload:device.message.payload,length:device.message.length,sha256:device.message.sha256});
  }
  async ack(deviceId, device, body) {
    if (!this.auth(device, body.token, 'deviceToken')) return json({ok:false,error:'unauthorized'},401);
    if (device.message && device.message.messageId === body.messageId && body.ok === true) device.message = null;
    await this.state.storage.put('device:' + deviceId, device, {expirationTtl: 60*60*24*365});
    return json({ok:true});
  }
}

function token(bytes) { const a = new Uint8Array(bytes); crypto.getRandomValues(a); return [...a].map(x=>x.toString(16).padStart(2,'0')).join(''); }
function json(value,status=200){ return new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}}); }
