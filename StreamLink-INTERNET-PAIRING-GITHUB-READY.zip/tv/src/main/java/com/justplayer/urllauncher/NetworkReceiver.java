package com.justplayer.urllauncher;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public final class NetworkReceiver implements AutoCloseable {
    public static final int TCP_PORT=45721, DISCOVERY_PORT=45722;
    private static final String REQUEST="SLINK_DISCOVER_V2";
    private volatile boolean running; private ServerSocket server; private DatagramSocket discovery;
    public synchronized void start(final Listener listener){ if(running)return; running=true;
        new Thread(() -> { try(ServerSocket s=new ServerSocket(TCP_PORT)){ server=s; while(running){ Socket c=null; try{ c=s.accept(); c.setSoTimeout(8000); final Socket client=c; new Thread(() -> handle(client,listener),"SLINK-client").start(); }catch(Exception ignored){} } }catch(Exception ignored){} },"SLINK-tcp").start();
        new Thread(() -> { try(DatagramSocket d=new DatagramSocket(DISCOVERY_PORT)){ discovery=d; d.setBroadcast(true); byte[] b=new byte[128]; while(running){ DatagramPacket q=new DatagramPacket(b,b.length); d.receive(q); String req=new String(q.getData(),q.getOffset(),q.getLength(),StandardCharsets.US_ASCII); if(REQUEST.equals(req)){ String name="Stream Link TV"; String response="SLINK_TV_V2|"+name+"|"+TCP_PORT; byte[] out=response.getBytes(StandardCharsets.UTF_8); d.send(new DatagramPacket(out,out.length,q.getAddress(),q.getPort())); } } }catch(Exception ignored){} },"SLINK-discovery").start();
    }
    private void handle(Socket s,Listener listener){ try(Socket c=s; DataInputStream in=new DataInputStream(c.getInputStream()); DataOutputStream out=new DataOutputStream(c.getOutputStream())){ try{ String url=TransferProtocol.receive(in); TransferProtocol.writeAck(out,true); listener.onUrl(url); }catch(Exception e){ try{TransferProtocol.writeAck(out,false);}catch(Exception ignored){} } }catch(Exception ignored){} }
    @Override public synchronized void close(){ running=false; try{if(server!=null)server.close();}catch(Exception ignored){} try{if(discovery!=null)discovery.close();}catch(Exception ignored){} }
    public interface Listener{void onUrl(String url);}
}
