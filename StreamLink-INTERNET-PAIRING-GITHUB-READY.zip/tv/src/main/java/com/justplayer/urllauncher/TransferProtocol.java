package com.justplayer.urllauncher;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

public final class TransferProtocol {
    private static final byte[] MAGIC = "SLINK2".getBytes(StandardCharsets.US_ASCII);
    private static final int VERSION = 1;
    private static final int MAX_URL_BYTES = 1024 * 1024;
    public static final byte ACK_OK = 1;
    public static final byte ACK_FAIL = 0;
    private TransferProtocol() {}
    public static void send(DataOutputStream out, String url) throws Exception {
        byte[] payload = url.getBytes(StandardCharsets.UTF_8);
        if (payload.length == 0 || payload.length > MAX_URL_BYTES) throw new IOException("Invalid URL size");
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(payload);
        out.write(MAGIC); out.writeByte(VERSION); out.writeInt(payload.length); out.write(hash); out.write(payload); out.flush();
    }
    public static String receive(DataInputStream in) throws Exception {
        byte[] magic = new byte[MAGIC.length]; in.readFully(magic);
        if (!Arrays.equals(magic, MAGIC) || in.readUnsignedByte() != VERSION) throw new IOException("Bad protocol");
        int length = in.readInt(); if (length <= 0 || length > MAX_URL_BYTES) throw new IOException("Bad payload length");
        byte[] expected = new byte[32]; in.readFully(expected); byte[] payload = new byte[length]; in.readFully(payload);
        byte[] actual = MessageDigest.getInstance("SHA-256").digest(payload);
        if (!MessageDigest.isEqual(expected, actual)) throw new IOException("Checksum mismatch");
        return new String(payload, StandardCharsets.UTF_8);
    }
    public static void writeAck(DataOutputStream out, boolean ok) throws IOException { out.writeByte(ok ? ACK_OK : ACK_FAIL); out.flush(); }
    public static boolean readAck(DataInputStream in) throws IOException { return in.readUnsignedByte() == ACK_OK; }
}
