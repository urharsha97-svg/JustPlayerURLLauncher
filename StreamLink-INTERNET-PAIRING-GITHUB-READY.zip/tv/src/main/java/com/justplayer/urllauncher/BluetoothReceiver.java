package com.justplayer.urllauncher;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.UUID;

public final class BluetoothReceiver implements AutoCloseable {
    public static final UUID SERVICE_UUID=UUID.fromString("7b1e8f40-8c36-4b1b-a9d5-3f8f7b3d7b11");
    private final Context context; private volatile boolean running; private BluetoothServerSocket server;
    public BluetoothReceiver(Context c){context=c.getApplicationContext();}
    private boolean allowed(){return Build.VERSION.SDK_INT<31 || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    public synchronized void start(final Listener listener){ if(running||!allowed())return; BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null||!a.isEnabled())return; running=true; new Thread(() -> { try{ server=a.listenUsingRfcommWithServiceRecord("Stream Link",SERVICE_UUID); while(running){ BluetoothSocket s=null; try{s=server.accept(); if(s==null)continue; final BluetoothSocket client=s; handle(client,listener);}catch(Exception ignored){} finally{try{if(s!=null)s.close();}catch(Exception ignored){}} } }catch(Exception ignored){} finally{closeServer();}},"SLINK-bt").start();}
    private void handle(BluetoothSocket s,Listener listener){try(BluetoothSocket c=s; DataInputStream in=new DataInputStream(c.getInputStream()); DataOutputStream out=new DataOutputStream(c.getOutputStream())){try{String url=TransferProtocol.receive(in); TransferProtocol.writeAck(out,true); listener.onUrl(url);}catch(Exception e){try{TransferProtocol.writeAck(out,false);}catch(Exception ignored){}}}catch(Exception ignored){}}
    private synchronized void closeServer(){try{if(server!=null)server.close();}catch(Exception ignored){} server=null;}
    @Override public synchronized void close(){running=false;closeServer();}
    public interface Listener{void onUrl(String url);}
}
