package com.justplayer.urllauncher;
import android.content.Context;
public final class StreamLinkReceiver implements AutoCloseable {
 private final NetworkReceiver network=new NetworkReceiver(); private final BluetoothReceiver bluetooth; private RelayReceiver relay;
 public StreamLinkReceiver(Context c){bluetooth=new BluetoothReceiver(c);}
 public void start(final Listener l){network.start(l::onUrl); bluetooth.start(l::onUrl);}
 public void startRelay(String base,String id,String token,final Listener l){relay=new RelayReceiver(base); relay.start(id,token,l::onUrl);}
 public void close(){network.close(); bluetooth.close(); if(relay!=null)relay.close();}
 public interface Listener{void onUrl(String url);}
}
