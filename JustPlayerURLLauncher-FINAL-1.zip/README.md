# Stream Link / Just Player URL Launcher

Android app for sending video URLs from a phone to an Android TV and receiving them on the TV.

## Device roles
- The same APK is installed on both devices.
- Phone: sender UI.
- Android TV: receiver UI.

## Transfer
- Bluetooth RFCOMM and local Wi-Fi/TCP discovery are supported.
- URL payloads are encoded as exact UTF-8 bytes.
- Framing includes magic, version, byte length, and SHA-256 integrity verification.
- Sender retries up to 3 times when acknowledgement fails.

## GitHub
The repository root contains `app/`, `.github/`, `build.gradle`, and `settings.gradle` directly.
